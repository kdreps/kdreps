import requests
import json
import time

API_URL = "http://localhost:5000/scrape"

def test_local_api(url):
    print(f"Testing Local Kakobuy API engine for: {url}")
    try:
        response = requests.get(API_URL, params={'url': url}, timeout=60)
        print(f"Status Code: {response.status_code}")
        print("Response JSON:")
        print(json.dumps(response.json(), indent=2, ensure_ascii=False))
    except Exception as e:
        print(f"API Request Failed: {e}")

if __name__ == "__main__":
    test_url = "https://weidian.com/item.html?itemID=7634893141"
    test_local_api(test_url)
