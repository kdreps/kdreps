from http.server import BaseHTTPRequestHandler
import json
import re
import urllib.parse
import urllib.request

# Platform scraping without Playwright — uses og:meta tags from mobile HTML
HEADERS = {
    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Referer": "https://www.google.com/",
}

def extract_item_id_and_platform(url):
    """Extract itemId and platform from any marketplace URL."""
    # Weidian
    m = re.search(r'itemI[dD]=(\d+)', url)
    if m and 'weidian' in url:
        return m.group(1), 'weidian'
    # Taobao / tmall
    m = re.search(r'[?&]id=(\d+)', url)
    if m and ('taobao' in url or 'tmall' in url):
        return m.group(1), 'taobao'
    # 1688
    m = re.search(r'offer/(\d+)\.html', url)
    if m:
        return m.group(1), '1688'
    return None, None

def fetch_html(url, timeout=8):
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            charset = 'utf-8'
            ct = resp.headers.get('Content-Type', '')
            if 'charset=' in ct:
                charset = ct.split('charset=')[-1].strip()
            return resp.read().decode(charset, errors='replace')
    except Exception as e:
        print(f"fetch_html error: {e}")
        return None

def parse_product_html(html, platform):
    """Extract product data from HTML using regex (og tags + JSON snippets)."""
    if not html:
        return None

    data = {"name": "", "priceCNY": "", "image": "", "platform": platform}

    # --- NAME ---
    og_title = re.search(r'property=["\']og:title["\'][^>]*content=["\']([^"\'<>]+)', html)
    if not og_title:
        og_title = re.search(r'content=["\']([^"\'<>]+)["\'][^>]*property=["\']og:title["\']', html)
    if og_title:
        data["name"] = og_title.group(1).strip()

    if not data["name"]:
        title_tag = re.search(r'<title>([^<]+)</title>', html)
        if title_tag:
            data["name"] = title_tag.group(1).replace('商品详情', '').replace('- 微店', '').strip()

    # --- IMAGE ---
    og_image = re.search(r'property=["\']og:image["\'][^>]*content=["\']([^"\'<>]+)', html)
    if not og_image:
        og_image = re.search(r'content=["\']([^"\'<>]+)["\'][^>]*property=["\']og:image["\']', html)
    if og_image:
        img = og_image.group(1).strip()
        if img.startswith('//'):
            img = 'https:' + img
        # Strip thumbnail params
        img = img.split('?')[0]
        data["image"] = img

    # Try geilicdn CDN directly (Weidian product images)
    if not data["image"]:
        cdn_imgs = re.findall(r'https?://(?:si|s)\.geilicdn\.com/[^\s"\'<>]+\.(?:jpg|jpeg|png|webp)', html)
        if cdn_imgs:
            # Prefer larger images
            cdn_imgs.sort(key=lambda x: '800' in x or '900' in x or 'unadjust' in x, reverse=True)
            data["image"] = cdn_imgs[0].split('?')[0]

    # --- PRICE ---
    # Weidian price patterns
    price_match = (
        re.search(r'"price"\s*:\s*"?([\d.]+)"?', html) or
        re.search(r'"cur_price"\s*:\s*"?([\d.]+)"?', html) or
        re.search(r'[¥￥]\s*([\d.]+)', html) or
        re.search(r'"amount"\s*:\s*"?([\d.]+)"?', html)
    )
    if price_match:
        data["priceCNY"] = price_match.group(1)

    return data

def scrape_weidian(item_id):
    """Scrape Weidian product page."""
    url = f"https://weidian.com/item.html?itemID={item_id}"
    html = fetch_html(url)
    return parse_product_html(html, 'weidian')

def scrape_taobao(item_id):
    """Scrape Taobao item page."""
    url = f"https://item.taobao.com/item.htm?id={item_id}"
    html = fetch_html(url)
    return parse_product_html(html, 'taobao')

def scrape_1688(item_id):
    """Scrape 1688 product page."""
    url = f"https://detail.1688.com/offer/{item_id}.html"
    html = fetch_html(url)
    return parse_product_html(html, '1688')

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        # CORS headers
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

        target_url = params.get('url', [None])[0]
        if not target_url:
            self.wfile.write(json.dumps({"error": "Missing url parameter"}).encode())
            return

        # Decode URL if needed
        target_url = urllib.parse.unquote(target_url)
        item_id, platform = extract_item_id_and_platform(target_url)

        result = None
        if platform == 'weidian' and item_id:
            result = scrape_weidian(item_id)
        elif platform == 'taobao' and item_id:
            result = scrape_taobao(item_id)
        elif platform == '1688' and item_id:
            result = scrape_1688(item_id)

        if result and (result.get('name') or result.get('image')):
            response = {
                "status": "success",
                "source": "vercel_api",
                "name": result.get("name", ""),
                "priceCNY": result.get("priceCNY", ""),
                "image": result.get("image", ""),
                "platform": platform,
            }
        else:
            response = {
                "status": "error",
                "message": "Could not extract product data",
                "platform": platform,
                "item_id": item_id,
            }

        self.wfile.write(json.dumps(response, ensure_ascii=False).encode('utf-8'))

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', '*')
        self.end_headers()

    def log_message(self, format, *args):
        pass  # Suppress default logging
