import json
import time
from playwright.sync_api import sync_playwright

def run(playwright):
    browser = playwright.chromium.launch(headless=False)
    page = browser.new_page()
    
    collected_responses = []
    
    def handle_response(response):
        if "shopDetail.tab.getItemList" in response.url or "shopDetail.tab.getCateItemList" in response.url:
            try:
                # We save the raw JSON response payload
                data = response.json()
                collected_responses.append(data)
                print(f"Intercepted Weidian API response. Total: {len(collected_responses)}")
            except Exception as e:
                pass

    page.on("response", handle_response)
    
    print("Navigating to Weidian store...")
    page.goto("https://weidian.com/?userid=1854069315&tabType=all", wait_until="networkidle")
    
    time.sleep(2)
    page.mouse.click(10, 10)
    time.sleep(1)
    
    print("Scrolling to load all items...")
    last_height = page.evaluate("document.body.scrollHeight")
    while True:
        page.evaluate("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(3)
        new_height = page.evaluate("document.body.scrollHeight")
        if new_height == last_height:
            time.sleep(5)
            new_height = page.evaluate("document.body.scrollHeight")
            if new_height == last_height:
                print("Reached the bottom of the page.")
                break
        last_height = new_height

    browser.close()

    print(f"Saving debug data...")
    with open("weidian_debug.json", "w", encoding="utf-8") as f:
        json.dump(collected_responses, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    with sync_playwright() as playwright:
        run(playwright)
